package com.techhub.demo.mockito.dto;

public class UserDto {

	private String id;
	private String name;
	private String userRole;

	public UserDto() {
	}

	public UserDto(String id, String name, String userRole) {
		super();
		this.id = id;
		this.name = name;
		this.userRole = userRole;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUserRole() {
		return userRole;
	}

	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}

	@Override
	public String toString() {
		return "UserDto [id=" + id + ", name=" + name + ", userRole=" + userRole + "]";
	}
}
