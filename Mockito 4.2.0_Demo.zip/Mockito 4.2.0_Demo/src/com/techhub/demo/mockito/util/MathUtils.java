package com.techhub.demo.mockito.util;

public class MathUtils {

	public int add(int x, int y) {
		return x + y;
	}

	public boolean isNumber(String s) {
		return s.matches("[0-9]+") ? true : false;
	}

	public int square(int l) {
		return l * l;
	}
}
