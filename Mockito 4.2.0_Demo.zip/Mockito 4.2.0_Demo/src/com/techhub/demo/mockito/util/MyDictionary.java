package com.techhub.demo.mockito.util;

import java.util.HashMap;
import java.util.Map;

public class MyDictionary {

	private Map<String, String> meanings;

	private Map<String, String> examples;

	public MyDictionary() {
		super();
		this.meanings = new HashMap<>();
		this.examples = new HashMap<>();
	}

	public void add(String word, String meaning, String example) {
		this.meanings.put(word, meaning);
		this.examples.put(word, example);
	}

	public String getMeaning(String word) {
		return this.meanings.get(word);
	}

	public String getExample(String word) {
		return this.examples.get(word);
	}
}
