package com.techhub.demo.mockito.service;

import com.techhub.demo.mockito.adaptor.UserAdaptor;
import com.techhub.demo.mockito.dto.UserDto;
import com.techhub.demo.mockito.model.User;
import com.techhub.demo.mockito.repository.UserRepository;

public class UserService {

	private UserRepository userRepository;

	public void setUserRepository(UserRepository userRepository) {
		this.userRepository = userRepository;
	}

	public UserDto getUser(String userId) {
		User user = this.userRepository.getUser(userId);
		UserDto userDto = UserAdaptor.toUserDto(user);
		return userDto;
	}

	public <T> T getUserDetails(String userId, Class<T> type) throws NoSuchMethodException, SecurityException {
		return userRepository.getUserDetails(userId, type);
	}
}
