package com.techhub.demo.mockito.adaptor;

import com.techhub.demo.mockito.dto.UserDto;
import com.techhub.demo.mockito.model.User;

public class UserAdaptor {

	private UserAdaptor() {
	}

	public static UserDto toUserDto(User user) {
		return new UserDto(user.getId(), user.getName(), user.getUserRole());
	}
	
	public static User toUser(UserDto userDto) {
		return new User(userDto.getId(), userDto.getName(), userDto.getUserRole());
	}
}
