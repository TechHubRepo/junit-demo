package com.techhub.demo.mockito.repository;

import java.util.HashMap;
import java.util.Map;

public class PhoneBookRepository {

	private Map<String, String> phoneBook;

	public PhoneBookRepository() {
		this.phoneBook = new HashMap<>();
	}

	public boolean contains(String name) {
		return this.phoneBook.containsKey(name);
	}

	public void insert(String name, String phone) {
		this.phoneBook.put(name, phone);
	}

	public String getPhoneNumberByContactName(String name) {
		return this.phoneBook.get(name);
	}

}
