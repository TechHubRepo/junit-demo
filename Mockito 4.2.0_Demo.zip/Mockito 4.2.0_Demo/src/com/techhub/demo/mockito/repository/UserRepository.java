package com.techhub.demo.mockito.repository;

import com.techhub.demo.mockito.exception.UserException;
import com.techhub.demo.mockito.model.User;

public class UserRepository {

	public User getUser(String id) {

		if (id != null && id.equals("U0001")) {
			return new User("U0001", "Shivam", "END_USER");
		} else {
			throw new UserException("User not found.");
		}
	}

	@SuppressWarnings("unchecked")
	public <T> T getUserDetails(String userId, Class<T> type) throws NoSuchMethodException, SecurityException {
		return (T) type.getConstructor();
	}

}
