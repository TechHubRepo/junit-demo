package com.techhub.demo.mockito.model;

public class UserProfile {

	private String userProfileImage;

	public String getUserProfileImage() {
		return userProfileImage;
	}

	public void setUserProfileImage(String userProfileImage) {
		this.userProfileImage = userProfileImage;
	}

	@Override
	public String toString() {
		return "UserProfile [userProfileImage=" + userProfileImage + "]";
	}
}
