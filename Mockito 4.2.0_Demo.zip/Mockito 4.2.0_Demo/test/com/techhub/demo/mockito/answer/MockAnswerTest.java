package com.techhub.demo.mockito.answer;

import java.util.List;
import java.util.logging.Logger;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.mockito.MockSettings;
import org.mockito.Mockito;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

public class MockAnswerTest {

	/** The LOGGER constant */
	private static Logger LOGGER = Logger.getLogger(MockAnswerTest.class.getSimpleName());

	/**
	 * Answer of Mockito
	 */
	@Disabled
	@Test
	public void answerTest() {
		@SuppressWarnings("unchecked")
		List<String> mockList = Mockito.mock(List.class, new BooleanAnswer());
		
		LOGGER.info("Flag : " + mockList.add("A"));
		LOGGER.info("Flag : " + mockList.add("B"));
		LOGGER.info("Flag : " + mockList.add("C"));
		LOGGER.info("Flag : " + mockList.add("D"));
		
		Assertions.assertTrue(mockList.add("X"));
		
//		Mockito.when(mockList.size()).thenReturn(5);
//		Assertions.assertEquals(5,mockList.size());
	}

	@Disabled
	@Test
	public void answerTest2() {
		@SuppressWarnings("unchecked")
		List<String> mockList = Mockito.mock(List.class);
		
		/** Mock Stubs */
		Mockito.when(mockList.add(Mockito.anyString())).thenAnswer(new BooleanAnswer());

		/** Mock Stubs */
		Mockito.when(mockList.size()).thenAnswer(new IntegerAnswer());

		Assertions.assertTrue(mockList.add("A"));
		Assertions.assertTrue(mockList.add("B"));
		Assertions.assertEquals(5, mockList.size());
	}

	/**
	 * Answer of Mockito
	 */
//	@Disabled
	@Test
	public void mockSettingTest() {
		
		MockSettings mockSettings = Mockito.withSettings();
		mockSettings.defaultAnswer(new IntegerAnswer());
			
		@SuppressWarnings("unchecked")
		List<String> mockList = Mockito.mock(List.class, mockSettings);
		
		Assertions.assertEquals(5, mockList.size());
	}
}

/**
 * BooleanAnswer of Mockito
 * 
 * @author ramniwash
 *
 */
class BooleanAnswer implements Answer<Boolean> {
	@Override
	public Boolean answer(InvocationOnMock invocation) throws Throwable {
		return true;
	}
}

/**
 * IntegerAnswer of Mockito
 * 
 * @author ramniwash
 *
 */
class IntegerAnswer implements Answer<Integer> {
	@Override
	public Integer answer(InvocationOnMock invocation) throws Throwable {
		return 5;
	}
}
