package com.techhub.demo.mockito.annotation;

import java.util.List;
import java.util.logging.Logger;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.techhub.demo.mockito.util.MathUtils;

public class CaptorAnnotationDemo {

	private static final Logger LOGGER = Logger.getLogger(CaptorAnnotationDemo.class.getName());

	@Mock
	private MathUtils mockMathUtil;

	@Captor
	private ArgumentCaptor<Integer> acNumber;

	@Captor
	private ArgumentCaptor<String> acString;

	@BeforeEach
	public void setUp() {

		/** Initialization for Mock Objects */
		MockitoAnnotations.openMocks(this);
	}

//	@SuppressWarnings("unchecked")
//	@Test
//	void whenNotUseCaptorAnnotation_thenCorrect() {
//
//		List<String> mockList = Mockito.mock(List.class);
//		ArgumentCaptor<String> ac2String = ArgumentCaptor.forClass(String.class);
//
//		mockList.add("one");
//		mockList.add("two");
//		mockList.add("three");
//		Mockito.verify(mockList, Mockito.times(3)).add(ac2String.capture());
//
//		LOGGER.info(ac2String.getAllValues().toString());
//		LOGGER.info(ac2String.getValue().toString());
//
//		Assertions.assertEquals("three", ac2String.getValue());
//	}

	@Test
	void test() {

		Mockito.when(mockMathUtil.add(Mockito.anyInt(), Mockito.anyInt())).thenReturn(2);
		Mockito.when(mockMathUtil.isNumber(Mockito.anyString())).thenReturn(true);
		Mockito.when(mockMathUtil.square(Mockito.anyInt())).thenReturn(4);

		Assertions.assertEquals(2, mockMathUtil.add(1, 1));
		Assertions.assertEquals(4, mockMathUtil.square(2));

		Assertions.assertTrue(mockMathUtil.isNumber("1"));
		Assertions.assertTrue(mockMathUtil.isNumber("999"));

		Mockito.verify(mockMathUtil).add(acNumber.capture(), acNumber.capture());
		Mockito.verify(mockMathUtil).square(acNumber.capture());

		List<Integer> allNumberValues = acNumber.getAllValues();
		Assertions.assertEquals(List.of(1, 1, 2), allNumberValues);
		LOGGER.info("ArgumentCaptor<Integer> ::: " + allNumberValues.toString());
		LOGGER.info("ArgumentCaptor<Integer> getValue ::: " + acNumber.getValue());

		Mockito.verify(mockMathUtil, Mockito.times(2)).isNumber(acString.capture());

		List<String> allStringValues = acString.getAllValues();
		Assertions.assertEquals(List.of("1", "999"), allStringValues);
		LOGGER.info("ArgumentCaptor<String> ::: " + allStringValues.toString());
		LOGGER.info("ArgumentCaptor<String> getValue ::: " + acString.getValue());
	}
}
