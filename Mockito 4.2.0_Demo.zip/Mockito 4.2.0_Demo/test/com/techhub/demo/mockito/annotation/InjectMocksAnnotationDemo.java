package com.techhub.demo.mockito.annotation;

import java.util.Map;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.techhub.demo.mockito.util.MyDictionary;

public class InjectMocksAnnotationDemo {

	@InjectMocks
	private MyDictionary myDictionary;

	@Mock
	private Map<String, String> myMock1;

	@Mock(name = "examples")
	private Map<String, String> myMock2;

	@BeforeEach
	public void setUp() {
		/** Initialization for Mock Objects */
		MockitoAnnotations.openMocks(this);
	}

	@CsvSource(value = { "Nameste, Used to greet someone, Nameste Krishana how are you?",
			"Program, The set of instruction for computer to do a task, Write a program to add three number." })
	@ParameterizedTest
	public void test(String word, String meaning, String example) {

		/** Writing Stubs for Mock/Spy */

		Mockito.when(this.myMock1.get(word)).thenReturn(meaning);
		Mockito.when(this.myMock2.get(word)).thenReturn(example);

//		Mockito.doReturn(meaning).when(this.meanings).get(word);
//		Mockito.doReturn(example).when(this.examples).get(word);

		Assertions.assertEquals(meaning, myDictionary.getMeaning(word));
		Assertions.assertEquals(example, myDictionary.getExample(word));
	}
}
