package com.techhub.demo.mockito.annotation;

import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

public class MockAnnotationDemo {

	private static final Logger LOGGER = Logger.getLogger(MockAnnotationDemo.class.getName());

	/** Creating Mock Object for List */
	@Mock
	private List<String> mockList;

	@BeforeEach
	public void setUp() {

		/** Initialization for Mock Objects */
		MockitoAnnotations.openMocks(this);
	}

	@AfterEach
	public void tearDown() {
		mockList.clear();
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testMethod1() {

		/** Creating the Mock for List */
		Map<String, String> mockMap = Mockito.mock(Map.class);

		/** Adding elements to Mock List [Operations on Mock] */
		mockMap.put("name", "ABC");
		mockMap.put("phone", "568652");
		mockMap.put("email", "hello@abc.com");

		/** Verify that particular operation is invoked on Mock */
		Mockito.verify(mockMap).put("name", "ABC");
		Mockito.verify(mockMap).put("phone", "568652");
		Mockito.verify(mockMap).put("email", "hello@abc.com");
		
		/** Stubs for List mock */
		Mockito.when(mockMap.get("email")).thenReturn("abcd@xyz.com");

		String email = mockMap.get("email");

		Assertions.assertEquals("abcd@xyz.com", email);

		LOGGER.info("Mock ::: " + mockMap.toString());
	}

	@Test
	public void testMethod2() {

		/** Adding elements into Mock List [Operations on Mock] */
		this.mockList.add("Nameste");
		this.mockList.add("Hello");
		this.mockList.add("Hai");

		/** Verify that particular operation is performed on Mock object */
		Mockito.verify(this.mockList).add("Nameste");
		Mockito.verify(this.mockList).add("Hello");
		Mockito.verify(this.mockList).add("Hai");

		Mockito.when(this.mockList.size()).thenReturn(3);
		Assertions.assertEquals(3, this.mockList.size());

		/** Stubs for List mock */
		Mockito.when(this.mockList.get(0)).thenReturn("ABC");

		String str = this.mockList.get(0);

		Assertions.assertEquals("ABC", str);

		LOGGER.info("Mock ::: " + this.mockList.toString());
	}
}
