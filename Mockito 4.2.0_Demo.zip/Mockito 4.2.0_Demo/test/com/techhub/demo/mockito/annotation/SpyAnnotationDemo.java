package com.techhub.demo.mockito.annotation;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;

public class SpyAnnotationDemo {

	private static final Logger LOGGER = Logger.getLogger(SpyAnnotationDemo.class.getName());

	@Spy
	private List<Integer> spyList = new ArrayList<>();

	@BeforeEach
	public void setUp() {

		/** Initialization for Mock Objects */
		MockitoAnnotations.openMocks(this);
	}

//	@Disabled
	@Test
	void testMethod1() {

		List<String> list = new ArrayList<>();

		/** Creating Spy for existing object **/
		List<String> spyList2 = Mockito.spy(list);

		spyList2.add("one");
		spyList2.add("two");

		/** Verify that particular operation added or not into Spy */
		Mockito.verify(spyList2).add("one");
		Mockito.verify(spyList2).add("two");
//		Mockito.verify(spyList).add("55");

		Assertions.assertEquals(2, spyList2.size());

		Mockito.when(spyList2.size()).thenReturn(100);

		int spyList2Size = spyList2.size();

		Assertions.assertEquals(100, spyList2Size);

		LOGGER.info("Spy ::: " + spyList2.toString());
	}

	@Test
	void testMethod2() {

		/** Adding elements into Spy List [Operations on Spy] */
		spyList.add(10);
		spyList.add(20);

		/** Verify that particular operation added or not into Spy */
		Mockito.verify(spyList).add(10);
		Mockito.verify(spyList).add(20);

		
		Assertions.assertEquals(2, spyList.size());

		Mockito.when(spyList.size()).thenReturn(100);

		Assertions.assertEquals(100, spyList.size());

		LOGGER.info("Spy ::: " + spyList.toString());
	}
}
