package com.techhub.demo.mockito.service;

import java.util.logging.Logger;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.techhub.demo.mockito.adaptor.UserAdaptor;
import com.techhub.demo.mockito.dto.UserDto;
import com.techhub.demo.mockito.exception.UserException;
import com.techhub.demo.mockito.model.Address;
import com.techhub.demo.mockito.model.User;
import com.techhub.demo.mockito.model.UserProfile;
import com.techhub.demo.mockito.repository.UserRepository;

public class UserServiceTest {

	/** The LOGGER constant */
	private static Logger LOGGER = Logger.getLogger(UserServiceTest.class.getSimpleName());

	@InjectMocks
	private UserService userService;

	@Mock
	private UserRepository userRepository;

	@BeforeEach
	public void setUpBeforeEach() {
		LOGGER.info("Entering into UserServiceTest -> setUpBeforeEach()");
		MockitoAnnotations.openMocks(this);
	}

	/**
	 * Test Positive case
	 */
	@Disabled
	@Test
	public void getUserTest() {
		LOGGER.info("Entering into UserServiceTest -> getUserTest()");

		User user = new User("U0001", "ABC", "ADMIN");

		/** Stubs for Mock userRepository */
		Mockito.when(this.userRepository.getUser(Mockito.anyString())).thenReturn(user);

		UserDto userDto = this.userService.getUser("U0001");

		LOGGER.info("userDto : " + userDto);

		Assertions.assertNotNull(userDto);
	}

	/**
	 * Test Exception case
	 */
	@Disabled
	@Test
	public void getUserTestException() {
		LOGGER.info("Entering into UserServiceTest -> getUserTestException()");

		/** Stubs for Mock userRepository */
		Mockito.when(this.userRepository.getUser(Mockito.anyString())).thenThrow(UserException.class);

		Executable executable = () -> {
			this.userService.getUser("U0002");
		};
		Assertions.assertThrows(UserException.class, executable);
	}

	/**
	 * Test for Static mock
	 */
	@Disabled
	@Test
	public void getUserStaticMockTest() {
		LOGGER.info("Entering into UserServiceTest -> getUserTest()");

		User user = new User("U0001", "ABC", "ADMIN");

		/** Stubs for Mock userRepository */
		Mockito.when(this.userRepository.getUser(Mockito.anyString())).thenReturn(user);

		/** Stubs for Static Mock of UserAdaptor */
		MockedStatic<UserAdaptor> mockedStatic = Mockito.mockStatic(UserAdaptor.class);

		UserDto userDto = new UserDto("U0005", "Super User", "SUPER_ADMIN");
		mockedStatic.when(() -> UserAdaptor.toUserDto(Mockito.any(User.class))).thenReturn(userDto);

		UserDto userDtoResp = this.userService.getUser("U0001");
		
		LOGGER.info("userDto : " + userDtoResp);
		
		Assertions.assertEquals("U0005",userDtoResp.getId());
	}

	/**
	 * ArgumentMatchers of Mockito
	 * 
	 * @throws NoSuchMethodException
	 * @throws SecurityException
	 */
//	@Disabled
	@Test
	public void getUserDetailsTest() throws NoSuchMethodException, SecurityException {
		
		UserProfile userProfile = new UserProfile();
		userProfile.setUserProfileImage("/path/to/file/image.jpg");
		
		/** Stubs for Mock userRepository */
		Mockito.when(this.userRepository.getUserDetails(ArgumentMatchers.anyString(),
				ArgumentMatchers.eq(UserProfile.class))).thenReturn(userProfile);
		
		UserProfile userProfileTemp = this.userService.getUserDetails("U0001", UserProfile.class);
		
		LOGGER.info("userProfileTemp : " + userProfileTemp);
		
		Assertions.assertNotNull(userProfileTemp);
	}

//	@Disabled
	@Test
	public void getUserDetailsTest2() throws NoSuchMethodException, SecurityException {

		Address address = new Address();
		address.setHomeTown("Near Govt. School");
		address.setStreet("Street 7th");
		address.setPinCode(125055);

		/** Stubs for Mock userRepository */
		Mockito.when(this.userRepository.getUserDetails(Mockito.anyString(), Mockito.eq(Address.class)))
				.thenReturn(address);
		
		Address addressTemp = this.userService.getUserDetails("U0001", Address.class);
		LOGGER.info("addressTemp : " + addressTemp);
		Assertions.assertNotNull(addressTemp);
	}
}
