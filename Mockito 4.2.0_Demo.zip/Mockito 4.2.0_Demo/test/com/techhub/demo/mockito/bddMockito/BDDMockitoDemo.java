package com.techhub.demo.mockito.bddMockito;

import java.util.logging.Logger;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.function.Executable;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.BDDMockito;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.invocation.InvocationOnMock;

import com.techhub.demo.mockito.repository.PhoneBookRepository;
import com.techhub.demo.mockito.service.PhoneBookService;

public class BDDMockitoDemo {

	/** The Constant LOGGER */
	private static final Logger LOGGER = Logger.getLogger(BDDMockitoDemo.class.getName());

	@InjectMocks
	private PhoneBookService phoneBookService;

	@Mock
	private PhoneBookRepository phoneBookRepository;

	@BeforeEach
	public void setUp() {
		LOGGER.info("Entering into BDDMockitoDemo -> setUp()");
		/** Initialization for Mock Objects */
		MockitoAnnotations.openMocks(this);
	}

	@Disabled
	@CsvSource(value = { "Arjun,9999999999" })
	@ParameterizedTest
	public void test1(String contactName, String contactNumber) {
		LOGGER.info("Entering into BDDMockitoDemo -> test1()");

		/**
		 * Stubs for PhoneBookRepository contains(String) method using BDDMockito in
		 * Mockito style
		 */

//		BDDMockito.when(phoneBookRepository.contains(contactName)).thenReturn(false);
//		phoneBookService.register(contactName, contactNumber);
//		Mockito.verify(phoneBookRepository).insert(contactName, contactNumber);

		/**
		 * Stubs for PhoneBookRepository contains(String) method using BDDMockito in
		 * BDDMockito style
		 */
		BDDMockito.given(phoneBookRepository.contains(contactName)).willReturn(false);
		phoneBookService.register(contactName, contactNumber);
		BDDMockito.then(phoneBookRepository).should().insert(contactName, contactNumber);
	}

	@Disabled
	@CsvSource(value = { "Arjun,9999999999" })
	@ParameterizedTest
	public void test2(String contactName, String contactNumber) {
		BDDMockito.given(phoneBookRepository.contains(contactName)).willReturn(false);
		phoneBookService.register(contactName, contactNumber);
		BDDMockito.then(phoneBookRepository).should(BDDMockito.never()).insert(contactName, contactNumber);
	}

	@Disabled
	@CsvSource(value = { "Arjun,9999999999" })
	@ParameterizedTest
	public void test3(String contactName, String contactNumber) {
		BDDMockito.given(phoneBookRepository.contains(contactName)).willReturn(true);
		BDDMockito.given(phoneBookRepository.getPhoneNumberByContactName(contactName)).will(
				(InvocationOnMock invocation) -> invocation.getArgument(0).equals("Arjun1") ? contactNumber : "ABC");
		String number = phoneBookService.search(contactName);
		LOGGER.info("number : " + number);
		BDDMockito.then(phoneBookRepository).should().getPhoneNumberByContactName(contactName);
	}

//	@Disabled
	@CsvSource(value = { "Arjun,9999999999" })
	@ParameterizedTest
	public void exceptionTestCase(String contactName, String contactNumber) {

		BDDMockito.given(phoneBookRepository.contains(BDDMockito.any(String.class))).willReturn(false);

		BDDMockito.willThrow(new RuntimeException("Mock Exception")).given(phoneBookRepository)
				.insert(BDDMockito.any(String.class), BDDMockito.eq(contactNumber));

		Executable executable = () -> {
			phoneBookService.register(contactName, contactNumber);
		};

		RuntimeException exception = Assertions.assertThrows(RuntimeException.class, executable);
		Assertions.assertEquals("Mock Exception", exception.getMessage());

//		BDDMockito.then(phoneBookRepository).should(BDDMockito.never()).insert(contactName, contactNumber);
	}
}
