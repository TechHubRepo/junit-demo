package com.techhub.demo.junit.repeated;

import java.util.logging.Logger;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.RepetitionInfo;
import org.junit.jupiter.api.TestInfo;

public class RepeatedTestDemo {

	/** The LOGGER */
	private static final Logger LOGGER = Logger.getAnonymousLogger();

	@BeforeEach
	void beforeEach(TestInfo testInfo, RepetitionInfo repetitionInfo) {
		int currentRepetition = repetitionInfo.getCurrentRepetition();
		int totalRepetitions = repetitionInfo.getTotalRepetitions();
		String methodName = testInfo.getTestMethod().get().getName();
		LOGGER.info(String.format("About to execute repetition %d of %d for %s", currentRepetition, totalRepetitions,
				methodName));
	}

	@Disabled
	@RepeatedTest(value = 4)
	public void repeatedTest() {
		LOGGER.info("@RepeatedTest ::: Entering into repeatedTest() test method.");
		Assertions.assertTrue(true);
	}

//	@Disabled
	@DisplayName("Repeat!")
	@RepeatedTest(value = 1, name = "{displayName} {currentRepetition}/{totalRepetitions}")
	public void customDisplayName(TestInfo testInfo) {
		LOGGER.info("@RepeatedTest ::: Entering into customDisplayName() test method.");
		LOGGER.info(testInfo.toString());
		Assertions.assertEquals("Repeat! 1/1", testInfo.getDisplayName());
	}

}
