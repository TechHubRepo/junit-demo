package com.techhub.demo.junit.tags;

import java.util.logging.Logger;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import com.techhub.demo.junit.MathUtil;

public class TestTegDemo2 {

	/** The LOGGER */
	private static final Logger LOGGER = Logger.getGlobal();

	private static MathUtil mathUtil = new MathUtil();

	@Test
	@Tag(value = "Positive")
	public void sumOfPositiveTest() {
		LOGGER.info("Entering sumOfPositiveTest");
		Assertions.assertEquals(11, mathUtil.sumOf(8, 3));
	}

	@Test
	@Tag(value = "Negative")
	public void sumOfNegativeTest() {
		LOGGER.info("Entering sumOfNegativeTest");
		Assertions.assertNotEquals(10, mathUtil.sumOf(8, 3));
	}

	@Test
	@Tag(value = "Positive")
	public void mulOfPositiveTest() {
		LOGGER.info("Entering mulOfPositiveTest");
		Assertions.assertEquals(24, mathUtil.mulOf(8, 3));
	}

	@Test
	@Tag(value = "Negative")
	public void mulOfNegativeTest2() {
		LOGGER.info("Entering mulOfNegativeTest2");
		Assertions.assertNotEquals(23, mathUtil.mulOf(8, 3));
	}
}
