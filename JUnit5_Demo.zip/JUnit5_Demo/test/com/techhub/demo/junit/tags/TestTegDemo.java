package com.techhub.demo.junit.tags;

import java.util.logging.Logger;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import com.techhub.demo.junit.ArrayUtil;

public class TestTegDemo {
	
	/** The LOGGER */
	private static final Logger LOGGER = Logger.getGlobal();

	private int[] inputArray = { 5, 9, 6, 4, 3, 12, 2 };

	private int[] sortedArray = { 2, 3, 4, 5, 6, 9, 12 };

	@Test
	@Tag(value="Positive")
	public void findElementPositveTest() {
		LOGGER.info("Entering findElementPositveTest");
		Assertions.assertEquals(1, ArrayUtil.findElement(inputArray, 9));
	}
	
	@Test
	@Tag(value="Negative")
	public void findElementNegativeTest() {
		LOGGER.info("Entering findElementNegativeTest");
		Assertions.assertNotEquals(1, ArrayUtil.findElement(inputArray, 8));
	}
	
	@Test
	@Tag(value="Positive")
	public void hasElementPositveTest() {
		LOGGER.info("Entering hasElementPositveTest");
		Assertions.assertTrue(ArrayUtil.hasElement(inputArray, 9));
	}
		
	@Test
	@Tag(value="Negative")
	public void hasElementNegativeTest() {
		LOGGER.info("Entering hasElementNegativeTest");
		Assertions.assertFalse(ArrayUtil.hasElement(inputArray, 8));
	}

	@Test
	@Tag(value="Positive")
	public void sortPositiveTest() {
		LOGGER.info("Entering sortPositiveTest");
		ArrayUtil.sort(inputArray);
		Assertions.assertArrayEquals(sortedArray, inputArray);
	}

}
