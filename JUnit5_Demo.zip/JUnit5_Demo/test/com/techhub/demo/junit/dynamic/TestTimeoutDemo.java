package com.techhub.demo.junit.dynamic;

import java.time.Duration;
import java.time.temporal.ChronoUnit;
import java.util.logging.Logger;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import com.techhub.demo.junit.ArrayUtil;
import com.techhub.demo.junit.MyCustomException;

public class TestTimeoutDemo {
	
	/** The LOGGER */
	private static final Logger LOGGER = Logger.getGlobal();

	private int[] inputArray;

	private int[] sortedArray = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12};

	@BeforeEach
	public void beforeEarch() {
		LOGGER.info("Entering into beforeEarch(..) method");
		inputArray = new int[] { 5, 9, 6, 4, 3, 12, 2, 1, 7, 11, 10, 8 };
	}

	@Disabled
//	@Timeout(1)
//	@Timeout(value = 1,unit = TimeUnit.MICROSECONDS)
	@Test
	public void timeoutTest() throws MyCustomException {
		LOGGER.info("Entering into timeoutTest(..) test method");
		ArrayUtil.sort(inputArray);
		Assertions.assertArrayEquals(sortedArray, inputArray);
	}
	
	@Disabled
	@Test
	public void timeoutTest2() throws MyCustomException {
		LOGGER.info("Entering into timeoutTest2(..) test method");
		Executable execution=()->{
			ArrayUtil.sort(inputArray);
		};
		Assertions.assertTimeout(Duration.of(1,ChronoUnit.SECONDS), execution);
	}

}
