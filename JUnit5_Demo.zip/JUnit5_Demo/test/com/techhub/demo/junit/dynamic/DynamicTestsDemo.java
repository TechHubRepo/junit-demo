package com.techhub.demo.junit.dynamic;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.TestFactory;
import org.junit.jupiter.api.function.Executable;

import com.techhub.demo.junit.StringUtils;

public class DynamicTestsDemo {

	/** The LOGGER */
	private static final Logger LOGGER = Logger.getGlobal();

	@TestFactory
	public List<DynamicTest> dynamicTestsFromCollection() {
		LOGGER.info("Entering into dynamicTestsFromCollection(..) test method");

		List<DynamicTest> dynamicTests = new ArrayList<>();

		String inputs[] = { "racecar", "radar", "able was I ere I saw elba", "1221", "@#$$#@", "xyz", "hello", "hai" };
		boolean[] outputs = { true, true, true, true, true, false, false, false };

		for (int i = 0; i < inputs.length; i++) {
			String input = inputs[i];
			boolean expected = outputs[i];
			String testCaseDisplayName = "DynamicTest" + i;

			Executable execution = () -> {
				Assertions.assertEquals(expected, StringUtils.isPalindrome(input));
			};

			dynamicTests.add(DynamicTest.dynamicTest(testCaseDisplayName, execution));
		}
		return dynamicTests;
	}
}
