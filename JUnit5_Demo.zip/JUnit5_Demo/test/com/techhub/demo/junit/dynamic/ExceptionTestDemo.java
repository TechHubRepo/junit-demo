package com.techhub.demo.junit.dynamic;

import java.util.logging.Logger;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import com.techhub.demo.junit.DataRepository;
import com.techhub.demo.junit.MyCustomException;

public class ExceptionTestDemo {

	/** The LOGGER */
	private static final Logger LOGGER = Logger.getGlobal();

	private DataRepository dataRepository = new DataRepository();

	@Test
	public void exceptionTest() throws MyCustomException {
		LOGGER.info("Entering into exceptionTest(..) test method");
		
		Executable executable=()->{
			dataRepository.getObjects(null);
		};
		MyCustomException exception = Assertions.assertThrows(MyCustomException.class, executable);
		Assertions.assertEquals("field name can't be empty", exception.getMessage());
	}
}
