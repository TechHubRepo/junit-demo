package com.techhub.demo.junit.dependencyinjection;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;

@DisplayName("TestInfo Demo")
public class TestInfoDemo {

	TestInfoDemo(TestInfo testInfo) {
		Assertions.assertEquals("TestInfo Demo", testInfo.getDisplayName());
	}

	@BeforeEach
	void init(TestInfo testInfo) {
		String displayName = testInfo.getDisplayName();
		Assertions.assertTrue(displayName.equals("TEST 1") || displayName.equals("test2()"));
	}

	@Test
	@DisplayName("TEST 1")
	@Tag("my-tag")
	void test1(TestInfo testInfo) {
		Assertions.assertEquals("TEST 1", testInfo.getDisplayName());
		Assertions.assertTrue(testInfo.getTags().contains("my-tag"));
	}

	@Test
	void test2() {
	}
}
