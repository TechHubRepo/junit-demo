package com.techhub.demo.junit.extension;

import java.util.logging.Logger;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.RegisterExtension;

public class ProgrammaticallyExtensionDemo {

	/** The LOGGER */
	private static final Logger LOGGER = Logger.getGlobal();

	@RegisterExtension
	static ExtensionB extensionB = new ExtensionB();

	/** Specific input can be passed to Extension in constructor */
	@RegisterExtension
	static ExtensionA extensionA = new ExtensionA();

	@Test
	public void test() {
		LOGGER.info("[ ProgrammaticallyExtensionDemo ] : => Entering into test() test method");
		Assertions.assertTrue(true);
	}
}
