package com.techhub.demo.junit.extension;

import java.util.logging.Logger;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class AutoExtensionRegisterDemo {
	
	/** The LOGGER */
	private static final Logger LOGGER = Logger.getGlobal();

	@Test
	public void test() {
		LOGGER.info("[ AutoExtensionRegisterDemo ] : => Entering into test() test method");
		Assertions.assertTrue(true);
	}
}
