package com.techhub.demo.junit.extension;

import java.util.logging.Logger;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@ExtendWith({ExtensionB.class,ExtensionA.class})
public class DeclarativelyExtensionDemo {
	
	/** The LOGGER */
	private static final Logger LOGGER = Logger.getGlobal();

//	@ExtendWith({ExtensionA.class,ExtensionB.class})
	@Test
	public void test() {
		LOGGER.info("[ DeclarativelyExtensionDemo ] : => Entering into test() test method");
		Assertions.assertTrue(true);
	}
	
	@Test
	public void test2() {
		LOGGER.info("[ DeclarativelyExtensionDemo ] : => Entering into test2() test method");
		Assertions.assertTrue(true);
	}
}
