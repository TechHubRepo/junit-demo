package com.techhub.demo.junit.extension;

import java.util.logging.Logger;

import org.junit.jupiter.api.extension.AfterAllCallback;
import org.junit.jupiter.api.extension.AfterEachCallback;
import org.junit.jupiter.api.extension.BeforeAllCallback;
import org.junit.jupiter.api.extension.BeforeEachCallback;
import org.junit.jupiter.api.extension.ExtensionContext;

public class ExtensionC implements BeforeAllCallback,AfterAllCallback, BeforeEachCallback, AfterEachCallback {

	/** The LOGGER */
	private static final Logger LOGGER = Logger.getGlobal();

	@Override
	public void beforeAll(ExtensionContext arg0) throws Exception {
		LOGGER.info("[ ExtensionC ] : => Entering into beforeAll() method");
	}
	
	@Override
	public void afterAll(ExtensionContext arg0) throws Exception {
		LOGGER.info("[ ExtensionC ] : => Entering into afterAll() method");
	}
	
	@Override
	public void beforeEach(ExtensionContext arg0) throws Exception {
		LOGGER.info("[ ExtensionC ] : => Entering into beforeEach() method");
	}

	@Override
	public void afterEach(ExtensionContext arg0) throws Exception {
		LOGGER.info("[ ExtensionC ] : => Entering into afterEach() method");
	}	
}
