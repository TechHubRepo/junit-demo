package com.techhub.demo.junit.interf;

import java.util.logging.Logger;

import org.junit.jupiter.api.Test;

public class TestInterfaceTestDemo implements MyFixtureInterface {

	private static final Logger LOGGER = Logger.getLogger(MyFixtureInterface.class.getName());
	
	@Test
	public void testA() {
		LOGGER.info("{ TestInterfaceTestDemo ] || Entering into testA() test method");
	}
}
