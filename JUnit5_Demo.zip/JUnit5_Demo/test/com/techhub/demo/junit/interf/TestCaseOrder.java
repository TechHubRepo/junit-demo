package com.techhub.demo.junit.interf;

import java.util.logging.Logger;

import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

@TestMethodOrder(OrderAnnotation.class)
public class TestCaseOrder {

	private static final Logger LOGGER = Logger.getLogger(MyFixtureInterface.class.getName());

	@Order(1)
	@Test
	public void testA() {
		LOGGER.info("{ TestInterfaceTestDemo ] || Entering into testA() test method");
	}
	
	@Order(4)
	@Test
	public void testB() {
		LOGGER.info("{ TestInterfaceTestDemo ] || Entering into testB() test method");
	}
	
	@Order(2)
	@Test
	public void testC() {
		LOGGER.info("{ TestInterfaceTestDemo ] || Entering into testC() test method");
	}
	
	@Order(3)
	@Test
	public void testD() {
		LOGGER.info("{ TestInterfaceTestDemo ] || Entering into testD() test method");
	}
}
