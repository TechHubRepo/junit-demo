package com.techhub.demo.junit.interf;

import java.util.logging.Logger;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.TestInfo;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;

@TestInstance(Lifecycle.PER_CLASS)
public interface MyFixtureInterface {

	public static final Logger LOGGER = Logger.getLogger(MyFixtureInterface.class.getName());

	@BeforeAll
	default void beforeAllTests() {
		LOGGER.info(":::: **** @BeforeAll tests **** ::::");
	}

	@AfterAll
	default void afterAllTests() {
		LOGGER.info(":::: **** @AfterAll tests **** ::::");
	}

	@BeforeEach
	default void beforeEachTest(TestInfo testInfo) {
		LOGGER.info(":::: **** @BeforeEach tests **** ::::");
		LOGGER.info(() -> String.format("About to execute [%s]", testInfo.getDisplayName()));
	}

	@AfterEach
	default void afterEachTest(TestInfo testInfo) {
		LOGGER.info(":::: **** @AfterEach tests **** ::::");
		LOGGER.info(() -> String.format("Finished executing [%s]", testInfo.getDisplayName()));
	}
}