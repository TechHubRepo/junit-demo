package com.techhub.demo.junit.fixtures;

import java.util.logging.Logger;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.techhub.demo.junit.MathUtil;

public class MathUtilTest {
	
	/** The LOGGER */
	private static final Logger LOGGER = Logger.getGlobal();

	private static MathUtil mathUtil;

	private int x;
	private int y;

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		LOGGER.info("*** @BeforeAll setUpBeforeClass() ***");
		mathUtil = new MathUtil();
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		LOGGER.info("*** @AfterAll setUpBeforeClass() ***");
		mathUtil = null;
	}

	@BeforeEach
	void setUp() throws Exception {
		LOGGER.info("*** @BeforeEach setUp() ***");
		x = 5;
		y = 3;
	}

	@AfterEach
	void tearDown() throws Exception {
		LOGGER.info("*** @AfterEach setUp() ***");
		x = 0;
		y = 0;
	}

	@Test
	void sumOfTest() {
		Assertions.assertEquals(8, mathUtil.sumOf(x, y));
	}
	
	@Test
	void mulOfTest() {
		Assertions.assertEquals(15, mathUtil.mulOf(x, y));
	}
}
