package com.techhub.demo.junit.nested;

import java.util.logging.Logger;

import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

public class NestedTestDemo {

	/** The LOGGER */
	private static final Logger LOGGER = Logger.getAnonymousLogger();

	@Test
	public void test1() {
		LOGGER.info("Entering into test1()");
	}
	
	@Nested
	class NestedClass{

		@Test
		public void nestedTest1() {
			LOGGER.info("Entering into nestedTest1()");
		}
	}
}
