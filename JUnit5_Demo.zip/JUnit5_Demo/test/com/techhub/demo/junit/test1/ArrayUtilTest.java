package com.techhub.demo.junit.test1;

import org.junit.jupiter.api.Assumptions;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.techhub.demo.junit.ArrayUtil;

import java.util.logging.Logger;

@DisplayName("ArrayUtil Test cases")
public class ArrayUtilTest {

	/** The LOGGER */
	private static final Logger LOGGER = Logger.getLogger(ArrayUtilTest.class.getName());

	private int[] inputArray = { 5, 9, 6, 4, 3, 12, 2 };

	@DisplayName("Find the Element index from Array Test case")
	@Test
	public void findElementTest() {
		LOGGER.info("Entering findElementTest");
		String os=System.getProperty("os.name");
		LOGGER.info("OS : "+os);
//		Assumptions.assumeFalse(true);
//		Assumptions.assumeTrue(false);
		Assumptions.assumingThat(true, () -> {
			Assertions.assertTrue(os.equals("Linux"));
        });
		int actualIndex = ArrayUtil.findElement(inputArray, 9);
		int expectedIndex = 1;
		Assertions.assertEquals(expectedIndex, actualIndex);
	}
	
	@Disabled
	@Test
	public void findElementTest2() {
		LOGGER.info("Entering findElementTest2");
		Assertions.assertEquals(1, ArrayUtil.findElement(inputArray, 9));
	}
	
	@org.junit.Test
//	@Test
	public void hasElement() {
		LOGGER.info("Entering hasElement");
		Assertions.assertTrue(ArrayUtil.hasElement(inputArray, 9));
	}
}
