package com.techhub.demo.junit.migration;

import java.util.logging.Logger;

public class Junit5Test {

	private static final Logger LOGGER = Logger.getLogger(Junit5Test.class.getName());

	@org.junit.jupiter.api.Test
	public void testX() {
		LOGGER.info("{ Junit5Test ] || Entering into testA() test method");
	}
}
