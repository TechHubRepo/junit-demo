package com.techhub.demo.junit.migration;

import java.util.logging.Logger;

import org.junit.jupiter.migrationsupport.EnableJUnit4MigrationSupport;
import org.junit.jupiter.migrationsupport.rules.EnableRuleMigrationSupport;

//@EnableRuleMigrationSupport
@EnableJUnit4MigrationSupport
public class Junit4Test {

	private static final Logger LOGGER = Logger.getLogger(Junit4Test.class.getName());

	@org.junit.Test
	public void testA() {
		LOGGER.info("{ Junit4Test ] || Entering into testA() test method");
	}
}
