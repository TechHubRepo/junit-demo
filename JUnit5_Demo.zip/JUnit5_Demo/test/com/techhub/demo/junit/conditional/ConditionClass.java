package com.techhub.demo.junit.conditional;

public class ConditionClass {

	public static boolean myCondition() {
		return true;
	}
}
