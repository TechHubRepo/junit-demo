package com.techhub.demo.junit.conditional;

import java.util.logging.Logger;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.DisabledForJreRange;
import org.junit.jupiter.api.condition.DisabledIf;
import org.junit.jupiter.api.condition.DisabledIfSystemProperties;
import org.junit.jupiter.api.condition.DisabledIfSystemProperty;
import org.junit.jupiter.api.condition.DisabledOnJre;
import org.junit.jupiter.api.condition.DisabledOnOs;
import org.junit.jupiter.api.condition.EnabledForJreRange;
import org.junit.jupiter.api.condition.EnabledIf;
import org.junit.jupiter.api.condition.EnabledIfEnvironmentVariable;
import org.junit.jupiter.api.condition.EnabledIfSystemProperty;
import org.junit.jupiter.api.condition.EnabledOnJre;
import org.junit.jupiter.api.condition.EnabledOnOs;
import org.junit.jupiter.api.condition.JRE;
import org.junit.jupiter.api.condition.OS;

public class ConditionalTestDemo {

	/** The LOGGER */
	private static final Logger LOGGER = Logger.getAnonymousLogger();

	/** Operating System Conditions */

	@Disabled
	@EnabledOnOs(OS.LINUX)
	@DisabledOnOs(OS.LINUX)
	@Test
	void onlyOnLinuxOs() {
		LOGGER.info("LINUX ::: Entering into onlyOnLinuxOs() test method.");
		Assertions.assertTrue(true);
	}

	@EnabledOnOs(OS.MAC)
	@Test
	void onlyOnMacOs() {
		LOGGER.info("MAC ::: Entering into onlyOnMacOs() test method.");
		Assertions.assertTrue(true);
	}

	@EnabledOnOs(OS.WINDOWS)
	@DisabledOnOs(OS.WINDOWS)
	@Test
	void onlyOnWindowsOs() {
		LOGGER.info("WINDOWS ::: Entering into onlyOnWindowsOs() test method.");
		Assertions.assertTrue(true);
	}

	/** Java Runtime Environment Conditions */

	@Disabled
	@EnabledOnJre(value = { JRE.JAVA_8 })
	@DisabledOnJre(value = { JRE.JAVA_10 })
	@Test
	void onlyOnJava8() {
		LOGGER.info("JAVA_8 ::: Entering into onlyOnJava8() test method.");
		Assertions.assertTrue(true);
	}

	@Disabled
	@EnabledOnJre(value = { JRE.JAVA_15 })
	@Test
	void onlyOnJava15() {
		LOGGER.info("JAVA_15 ::: Entering into onlyOnJava15() test method.");
		Assertions.assertTrue(true);
	}

	@Disabled
	@DisabledForJreRange(min = JRE.JAVA_9, max = JRE.JAVA_11)
	@Test
	void notFromJava9to11() {
		LOGGER.info("JAVA_9 to JAVA_11 ::: Entering into notFromJava9to11() test method.");
		Assertions.assertTrue(true);
	}

	@Disabled
	@DisabledForJreRange(min = JRE.JAVA_9, max = JRE.JAVA_15)
	@Test
	void notFromJava9to15() {
		LOGGER.info("JAVA_9 to JAVA_15 ::: Entering into notFromJava9to11() test method.");
		Assertions.assertTrue(true);
	}

	@Disabled
	@EnabledForJreRange(min = JRE.JAVA_9, max = JRE.JAVA_15)
	@Test
	void onJreFromJava9to15() {
		LOGGER.info("JAVA_9 to JAVA_15 ::: Entering into onJreFromJava9to15() test method.");
		Assertions.assertTrue(true);
	}

	/** System Property Conditions */
	@Disabled
	@EnabledIfSystemProperty(named = "os.arch", matches = ".*64.*")
//	@DisabledIfSystemProperty(named = "os.arch", matches = ".*64.*")
	@Test
	void onlyOn64BitArchitectures() {
		LOGGER.info("64BitArchitecture ::: Entering into onlyOn64BitArchitectures() test method.");
	}

	/** Environment Variable Conditions */

	@Disabled
	@EnabledIfEnvironmentVariable(named = "ENV", matches = "staging-server")
	@Test
	void onlyOnStagingServer() {
		LOGGER.info("staging-server ::: Entering into onlyOnStagingServer() test method.");
	}

	@Disabled
	@EnabledIfEnvironmentVariable(named = "ENV", matches = ".*development.*")
	@Test
	void notOnDeveloperWorkstation() {
		LOGGER.info("development ::: Entering into notOnDeveloperWorkstation() test method.");
	}

	/** Custom Conditions */

	@Disabled
	@EnabledIf("customCondition")
	@Test
	void enabled() {
		LOGGER.info("customCondition ::: Entering into enabled() test method.");
	}

	@Disabled
	@DisabledIf("customCondition")
	@Test
	void disabled() {
		LOGGER.info("customCondition ::: Entering into disabled() test method.");
	}

	boolean customCondition() {
		return false;
	}

	/**
	 * Alternatively, the condition method can be located outside the test class. In
	 * this case, it has to be referenced by its fully qualified name as
	 * demonstrated in the following example.
	 */
//	@Disabled
	@Test
	@EnabledIf("com.techhub.demo.junit.conditional.ConditionClass#myCondition")
	void customeExternalCondition() {
		LOGGER.info("myCondition ::: Entering into customeExternalCondition() test method.");
	}
}
