package com.techhub.demo.junit.parameterized;

import java.util.List;

public class ParameterizedInputClass {

	public static List<Integer> numbers() {
		return List.of(5, 9, 6, 4, 7, 3, 1, 8);
	}

}
