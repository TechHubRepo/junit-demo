package com.techhub.demo.junit.parameterized;

import java.time.DayOfWeek;
//import java.time.Month;
//import java.time.temporal.ChronoUnit;
import java.util.Arrays;
import java.util.List;
import java.util.logging.Logger;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Assumptions;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.ArgumentsSource;
import org.junit.jupiter.params.provider.CsvFileSource;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.EmptySource;
import org.junit.jupiter.params.provider.EnumSource;
//import org.junit.jupiter.params.provider.EnumSource.Mode;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.NullAndEmptySource;
import org.junit.jupiter.params.provider.NullSource;
import org.junit.jupiter.params.provider.ValueSource;

import com.techhub.demo.junit.StringUtils;

/**
 * ParameterizedTestDemo class
 * 
 * @author ramniwash
 */
public class ParameterizedTestDemo {

	/** The LOGGER */
	private static final Logger LOGGER = Logger.getGlobal();

	/** @ValueSource Demo */

	@Disabled
	@ValueSource(strings = { "racecar", "radar", "able was I ere I saw elba", "1221", "@#$$#@" })
	@ParameterizedTest
	public void palindromes(String str) {
		LOGGER.info("Entering into palindromes(..) test method");
		LOGGER.info(str);
		Assertions.assertTrue(StringUtils.isPalindrome(str));
	}

//	@Disabled
	@ValueSource(ints = { 1, 2, 3 })
	@ParameterizedTest
	public void valueSourceTest(int argument) {
		LOGGER.info("Entering into valueSourceTest(..) test method");
		LOGGER.info(argument + "");
		Assertions.assertTrue(argument > 0 && argument < 4);
	}

	/** @NullSource Demo */

	@Disabled
	@NullSource
	@ParameterizedTest
	public void nullSourceTest(String str) {
		LOGGER.info("Entering into nullSourceTest(..) test method");
		LOGGER.info(str);
		Assertions.assertNull(str);
	}

	/** @EmptySource Demo */

	@Disabled
	@EmptySource
	@ParameterizedTest
	public void emptySourceTest(String str[]) {
		LOGGER.info("Entering into emptySourceTest(..) test method");
		Assertions.assertEquals(0, str.length);
	}

	/** @NullAndEmptySource Demo */

	@Disabled
	@NullAndEmptySource
	@ParameterizedTest
	public void nullAndEmptySourceTest(int str[]) {
		LOGGER.info("Entering into nullAndEmptySourceTest(..) test method");
		LOGGER.info(Arrays.toString(str));
		Assumptions.assumeTrue(str != null);
		Assertions.assertEquals(0, str.length);
	}

	/** @EnumSource Demo */

	@Disabled
//	@EnumSource(DayOfWeek.class)
	@EnumSource(names = { "MONDAY", "WEDNESDAY", "FRIDAY" })
//	@EnumSource(mode = Mode.EXCLUDE, names = { "SATURDAY", "SUNDAY" })
//	@EnumSource(mode = Mode.MATCH_ALL, names = "(T).*$")
//	@EnumSource(Month.class)
	@ParameterizedTest
	public void enumSourceTest(DayOfWeek enumRef) {
		LOGGER.info("Entering into enumSourceTest(..) test method");
		LOGGER.info(enumRef.toString());
		Assertions.assertNotNull(enumRef);
	}

	/** @MethodSource Demo */

	@Disabled
	@MethodSource("stringProvider")
	@ParameterizedTest
	public void methodSourceTest(String argument) {
		LOGGER.info("Entering into methodSourceTest(..) test method");
		LOGGER.info(argument);
		Assertions.assertNotNull(argument);
	}

	private static Stream<String> stringProvider() {
		return Stream.of("Apple", "Banana", "Blackberry", "Fig", "Grapes");
	}

	@Disabled
	@MethodSource
	@ParameterizedTest
	public void methodSourceTest2(int argument) {
		LOGGER.info("Entering into methodSourceTest2(..) test method");
		LOGGER.info(argument + "");
		Assertions.assertTrue(argument >= 10);
	}

	private static IntStream methodSourceTest2() {
		return IntStream.range(1, 20).skip(10);
	}

	@Disabled
	@MethodSource("numbers")
	@ParameterizedTest
	public void methodSourceTest3(int argument) {
		LOGGER.info("Entering into methodSourceTest3(..) test method");
		LOGGER.info(argument + "");
		Assertions.assertTrue(argument <= 10);
	}

	private static int[] numbers() {
		return new int[] { 5, 8, 2, 6, 4 };
	}

	@Disabled
	@MethodSource("numbers2")
	@ParameterizedTest
	public void methodSourceTest4(int argument) {
		LOGGER.info("Entering into methodSourceTest3(..) test method");
		LOGGER.info(argument + "");
		Assertions.assertTrue(argument <= 10);
	}

	private static List<Integer> numbers2() {
		return List.of(5, 8, 2, 6, 4);
	}

	@Disabled
	@MethodSource("stringIntAndListProvider")
	@ParameterizedTest
	void methodSourceWithMultiArgTest(String str, int num, List<String> list) {
		LOGGER.info("Entering into methodSourceWithMultiArgTest(..) test method");
		LOGGER.info(str + " : " + num + " : " + list);
		Assertions.assertEquals(5, str.length());
		Assertions.assertTrue(num >= 1 && num <= 2);
		Assertions.assertEquals(2, list.size());
	}

	private static Stream<Arguments> stringIntAndListProvider() {
		return Stream.of(Arguments.arguments("apple", 1, Arrays.asList("a", "b")),
				Arguments.arguments("lemon", 2, Arrays.asList("x", "y")));
	}

	@Disabled
	@MethodSource("com.techhub.demo.junit.parameterized.ParameterizedInputClass#numbers")
	@ParameterizedTest
	public void methodSourceExternal(int argument) {
		LOGGER.info("Entering into methodSourceTest3(..) test method");
		LOGGER.info(argument + "");
		Assertions.assertTrue(argument <= 10);
	}

	/** @CsvSource */

	@Disabled
	@CsvSource({ "apple,1", "banana,2", "'lemon, lime', 0xF1", "strawberry,700000" })
	@ParameterizedTest
	public void csvSourceTest(String fruit, int rank) {
		LOGGER.info("Entering into csvSourceTest(..) test method");
		LOGGER.info(fruit + " : " + rank);
		Assertions.assertNotNull(fruit);
		Assertions.assertNotEquals(0, rank);
	}

	@Disabled
	@CsvFileSource(resources = "/temp-file.csv", numLinesToSkip = 1)
	@ParameterizedTest
	public void csvFileSourceTest(String name, String email, int number, String address) {
		LOGGER.info("Entering into csvFileSourceTest(..) test method");
		Assertions.assertNotNull(name);
		Assertions.assertNotNull(email);
		Assertions.assertNotNull(address);
		Assertions.assertNotEquals(0, number);
	}

	@Disabled
	@ArgumentsSource(ArgumentsProviderImp.class)
	@ParameterizedTest
	public void argumentsSourceTest(String str) {
		LOGGER.info("Entering into argumentsSourceTest(..) test method");
		Assertions.assertNotNull(str);
	}
}
