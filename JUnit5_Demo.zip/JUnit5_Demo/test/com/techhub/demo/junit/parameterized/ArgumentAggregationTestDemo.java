package com.techhub.demo.junit.parameterized;

import java.time.LocalDate;
import java.util.logging.Logger;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.aggregator.AggregateWith;
import org.junit.jupiter.params.aggregator.ArgumentsAccessor;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;

public class ArgumentAggregationTestDemo {

	/** The LOGGER */
	private static final Logger LOGGER = Logger.getGlobal();

	@Disabled
	@ValueSource(strings = { "Nameste", "Hi", "Hello", "Swagatam", "Welcome" })
	@ParameterizedTest
	public void argumentsAccessorTest(ArgumentsAccessor arguments) {
		LOGGER.info("Entering into argumentsAccessorTest(..) test method");
		String word = arguments.getString(0);
		LOGGER.info(word);
		Assertions.assertNotNull(word);
	}

	@Disabled
	@CsvSource({ "Harish, Kumar, M, 1996-05-20", "Shree, Devi, F, 1998-10-22" })
	@ParameterizedTest
	public void argumentsAccessorTest2(ArgumentsAccessor arguments) {
		LOGGER.info("Entering into argumentsAccessorTest2(..) test method");
		String fName = arguments.get(0, String.class);
		String lName = arguments.get(1, String.class);
		char gender = arguments.get(2, Character.class);
		LocalDate dob = arguments.get(3, LocalDate.class);
	
		LOGGER.info(fName);
		LOGGER.info(lName);
		LOGGER.info(String.valueOf(gender));
		LOGGER.info(dob.toString());

		Assertions.assertNotNull(fName);
		Assertions.assertNotNull(lName);
		Assertions.assertNotNull(gender);
		Assertions.assertNotNull(dob);
	}

//	@Disabled
	@CsvSource({ "Harish, Kumar, M, 1996-05-20", "Shree, Devi, F, 1998-10-22" })
	@ParameterizedTest
	public void aggregateWithTest(@AggregateWith(PersonAggregator.class) Person person) {
		LOGGER.info("Entering into aggregateWithTest(..) test method");
		LOGGER.info(person.toString());
		Assertions.assertNotNull(person);
	}
}
