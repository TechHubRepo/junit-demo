package com.techhub.demo.junit.parameterized;

import java.time.LocalDate;
import java.time.Month;
import java.time.temporal.ChronoUnit;
import java.util.logging.Logger;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.converter.ConvertWith;
import org.junit.jupiter.params.converter.JavaTimeConversionPattern;
import org.junit.jupiter.params.provider.EnumSource;
import org.junit.jupiter.params.provider.ValueSource;

public class ArgumentConversionTestDemo {

	/** The LOGGER */
	private static final Logger LOGGER = Logger.getGlobal();

	/** Implicit Argument Conversion */

	@Disabled
	@ValueSource(strings = { "SECONDS" })
	@ParameterizedTest
	public void implicitArgumentConversionTest(ChronoUnit argument) {
		LOGGER.info("Entering into implicitArgumentConversionTest(..) test method");
		LOGGER.info(argument.name());
		Assertions.assertNotNull(argument.name());
	}

	@Disabled
	@ValueSource(strings = { "APRIL" })
	@ParameterizedTest
	public void implicitArgumentConversionTest(Month argument) {
		LOGGER.info("Entering into implicitArgumentConversionTest(..) test method");
		LOGGER.info(argument.name());
		Assertions.assertNotNull(argument.name());
	}

	@Disabled
	@ValueSource(strings = { "1", "2", "3" })
	@ParameterizedTest
	public void implicitArgumentConversionTest(int argument) {
		LOGGER.info("Entering into implicitArgumentConversionTest(..) test method");
		LOGGER.info(argument + "");
		Assertions.assertTrue(argument > 0 && argument < 4);
	}

	/** Explicit Argument Conversion */

	@Disabled
	@ParameterizedTest
	@ValueSource(strings = { "01-01-2017", "31-12-2017" })
	public void explicitJavaTimeConverterTest(@JavaTimeConversionPattern("dd-MM-yyyy") LocalDate argument) {
		LOGGER.info("Entering into explicitJavaTimeConverterTest(..) test method");
		LOGGER.info(argument.toString());
		Assertions.assertEquals(2017, argument.getYear());
	}

	@Disabled
	@EnumSource(ChronoUnit.class)
	@ParameterizedTest
	public void explicitArgumentConversionTest1(@ConvertWith(MySimpleArgumentConverter.class) String argument) {
		LOGGER.info("Entering into explicitArgumentConversionTest2(..) test method");
		LOGGER.info(argument);
		Assertions.assertNotNull(argument);
	}

//	@Disabled
	@ValueSource(strings = { "1", "3", "9", "4", "hello", "Hi", "Java", "Computer", "7", "" })
	@ParameterizedTest
	public void explicitArgumentConversionTest2(@ConvertWith(MyTypedArgumentConverter.class) Integer number) {
		LOGGER.info("Entering into explicitArgumentConversionTest2(..) test method");
		LOGGER.info(number+"");
		Assertions.assertTrue(number < 10);
	}
}
