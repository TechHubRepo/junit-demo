package com.techhub.demo.junit.parameterized;

import org.junit.jupiter.params.converter.TypedArgumentConverter;

public class MyTypedArgumentConverter extends TypedArgumentConverter<String, Integer> {

	public MyTypedArgumentConverter() {
		super(String.class, Integer.class);
	}

	@Override
	protected Integer convert(String source) {
		if (source == null) {
			return 0;
		} else if (source.matches("[0-9]+")) {
			return Integer.parseInt(source);
		} else {
			return source.length();
		}
	}
}
