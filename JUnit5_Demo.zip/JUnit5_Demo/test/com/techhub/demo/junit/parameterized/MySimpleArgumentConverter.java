package com.techhub.demo.junit.parameterized;

import java.util.logging.Logger;

import org.junit.jupiter.params.converter.ArgumentConversionException;
import org.junit.jupiter.params.converter.SimpleArgumentConverter;

public class MySimpleArgumentConverter extends SimpleArgumentConverter {

	/** The LOGGER */
	private static final Logger LOGGER = Logger.getGlobal();

	@Override
	protected Object convert(Object source, Class<?> type) throws ArgumentConversionException {
		LOGGER.info("source : " + source);
		LOGGER.info("type : " + type);
		if (source instanceof Enum<?>) {
			return ((Enum<?>) source).name();
		}
		return String.valueOf(source);
	}
}
