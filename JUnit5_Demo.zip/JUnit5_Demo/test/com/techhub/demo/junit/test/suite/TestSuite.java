package com.techhub.demo.junit.test.suite;

import org.junit.platform.runner.JUnitPlatform;
import org.junit.platform.suite.api.SelectClasses;
//import org.junit.platform.suite.api.ExcludeClassNamePatterns;
//import org.junit.platform.suite.api.IncludeClassNamePatterns;
import org.junit.platform.suite.api.SelectPackages;
import org.junit.runner.RunWith;

@RunWith(JUnitPlatform.class)
@SelectPackages({ "com.techhub.demo.junit.test1", "com.techhub.demo.junit.fixtures",
		"com.techhub.demo.junit.tags" })
//@IncludeClassNamePatterns(value = {"Demo"})     //Include only those class contains "abc" in name
//@ExcludeClassNamePatterns(value = {"Demo"})    //Include those classes contains "xyz"  in name
@SelectClasses({})
public class TestSuite {

}
