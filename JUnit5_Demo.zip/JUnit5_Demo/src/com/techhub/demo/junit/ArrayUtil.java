package com.techhub.demo.junit;

public class ArrayUtil {

	private ArrayUtil() {
	}

	public static int findElement(int[] arr, int element) {
		int idx = -1;
		if (arr != null && arr.length > 0) {
			for (int i = 0; i < arr.length; i++) {
				if (arr[i] == element) {
					idx = i;
					break;
				}
			}
		}
		return idx;
	}

	public static void sort(int[] arr) {
		if (arr != null && arr.length > 0) {
			for (int i = 0; i < arr.length; i++) {
				for (int j = 0; j < arr.length; j++) {
					if (i != j) {
						if (arr[j] > arr[i]) {
							int t = arr[j];
							arr[j] = arr[i];
							arr[i] = t;
						}
					}
				}
			}
		}
	}

	public static boolean hasElement(int[] arr, int element) {
		if (arr != null && arr.length > 0) {
			for (int i = 0; i < arr.length; i++) {
				if (arr[i] == element) {
					return true;
				}
			}
		}
		return false;
	}
}
