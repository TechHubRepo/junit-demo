package com.techhub.demo.junit;

import java.io.Closeable;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class DataRepository implements Closeable {

	public <T> T getObject(String id, Class<T> type) throws MyCustomException, Exception {
		if (id == null) {
			throw new MyCustomException("id can't be null");
		} else if (id.equals("ID0001")) {
			return type.getConstructor().newInstance();
		} else {
			return null;
		}
	}

	public List<String> getObjects(String field) throws MyCustomException {

		if (field == null || field.isBlank()) {
			throw new MyCustomException("field name can't be empty");
		}
		
		List<String> list = new ArrayList<>();
		if (field.equals("CITY")) {
			list.add("Delhi");
			list.add("Chandigarh");
			list.add("Mumbai");
			list.add("Chennai");
			list.add("Bhagyanagar");
		}
		
		if (field.equals("COUNTRY")) {
			list.add("INDIA");
			list.add("SRI LANKA");
			list.add("BURMA");
			list.add("NEPAL");
			list.add("USA");
			list.add("RUSSIA");
		}
		return list;
	}

	@Override
	public void close() throws IOException {
		System.out.println("::::: Closing the Resources ..... ");
	}
}
