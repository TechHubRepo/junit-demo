package com.techhub.demo.junit;

public class StringUtils {

	private StringUtils() {
	}

	public static boolean isPalindrome(String string) {
		boolean flag = true;
		char tempArray[] = string.toCharArray();
		for (int i = 0; i < tempArray.length-1 / 2; i++) {
			if (tempArray[i] != tempArray[tempArray.length-1 - i]) {
				flag = false;
				break;
			}
		}
		return flag;
	}
}
