package com.techhub.demo.junit;

import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

public class DataRepositoryTest3 {

	private static DataRepository dataRepository;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		dataRepository = new DataRepository();
	}
	
	@Test
	public void getObjectTest() throws MyCustomException, Exception {
		String data = dataRepository.getObject("ID0001", String.class);
		Assert.assertNotNull(data);
	}

	@Test(expected = MyCustomException.class)
	public void getObjectTest2() throws MyCustomException, Exception {
		dataRepository.getObject(null, String.class);
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		dataRepository.close();
		dataRepository = null;
	}
}
