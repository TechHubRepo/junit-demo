package com.techhub.demo.junit;

import org.junit.experimental.categories.Categories;
import org.junit.experimental.categories.Categories.ExcludeCategory;
import org.junit.experimental.categories.Categories.IncludeCategory;
import org.junit.runner.RunWith;
import org.junit.runners.Suite.SuiteClasses;

import com.techhub.demo.junit.cate.NegativeTestCase;
import com.techhub.demo.junit.cate.PostiveTestCase;

@RunWith(Categories.class)
@IncludeCategory({PostiveTestCase.class,NegativeTestCase.class})
@ExcludeCategory({NegativeTestCase.class}) 
@SuiteClasses({ ArrayUtilTest2.class, DataRepositoryTest4.class })
public class CategorySuite {

}
