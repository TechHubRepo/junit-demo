package com.techhub.demo.junit;

import java.util.Arrays;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

//Step 1
@RunWith(Parameterized.class)
public class MathUtilTest2 {

	private MathUtil mathUtil;

	// Step 2
	/** First Number */
	public int x;
	/** Second Number */
	public int y;
	/** Sum of X and Y */
	public int sum;
	/** Multiplication of X and Y */
	public int mul;

	// Step 3
	public MathUtilTest2(int x, int y, int sum, int mul) {
		this.mathUtil = new MathUtil();
		this.x = x;
		this.y = y;
		this.sum = sum;
		this.mul = mul;
	}

	// Step 4
	@Parameters
	public static List<Integer[]> inputOututs() {
		Integer[][] inputes = { { 7, 3, 10, 21 }, { 6, 5, 11, 30 }, { 20, 10, 30, 200 }, { 5, 3, 8, 15 },
				{ 9, 6, 15, 54 }, { 8, 4, 12, 32 } ,{4,3,7,12}};
		return Arrays.asList(inputes);
	}

	@Test
	public void sumOfTest() {
		int sum = mathUtil.sumOf(this.x, this.y);
		Assert.assertEquals(this.sum, sum);
	}

	@Test
	public void mulOfTest() {
		int mul = mathUtil.mulOf(this.x, this.y);
		Assert.assertEquals(this.mul, mul);
	}
}
