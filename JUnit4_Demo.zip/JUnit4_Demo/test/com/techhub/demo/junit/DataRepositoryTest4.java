package com.techhub.demo.junit;

import java.util.List;

import org.hamcrest.CoreMatchers;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import com.techhub.demo.junit.cate.NegativeTestCase;
import com.techhub.demo.junit.cate.PostiveTestCase;

public class DataRepositoryTest4 {

	private static DataRepository dataRepository;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.out.println("******* BeforeClass (setUp) *******");
		dataRepository = new DataRepository();
	}

	@Category(PostiveTestCase.class)
	@Test
	public void getObjectTest() throws MyCustomException, Exception {
		String dataObject = dataRepository.getObject("ID0001", String.class);
		Assert.assertNotNull(dataObject);
	}
	
	@Category(NegativeTestCase.class)
	@Test
	public void getObjectTest3() throws MyCustomException, Exception {
		String dataObject = dataRepository.getObject("ID0002", String.class);
		Assert.assertNull(dataObject);
	}

	@Category(NegativeTestCase.class)
	@Test(expected = MyCustomException.class)
	public void getObjectTest2() throws MyCustomException, Exception {
		dataRepository.getObject(null, String.class);
	}

	@Category(PostiveTestCase.class)
	@Test
	public void getObjectsTest() throws MyCustomException {
		List<String> list = dataRepository.getObjects("CITY");
//		Assert.assertThat(list, CoreMatchers.hasItem("Delhi"));
//		Assert.assertThat(list.size(), CoreMatchers.is(5));
		org.hamcrest.MatcherAssert.assertThat(list, CoreMatchers.hasItem("Delhi"));
	}
	
	@Category(PostiveTestCase.class)
	@Test
	public void getObjectsTestCountry() throws MyCustomException {
		List<String> list = dataRepository.getObjects("COUNTRY");
//		Assert.assertThat(list, CoreMatchers.hasItem("Delhi"));
//		Assert.assertThat(list.size(), CoreMatchers.is(5));
		org.hamcrest.MatcherAssert.assertThat(list, CoreMatchers.hasItem("INDIA"));
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		System.out.println("******* AfterClass (tearDown) *******");
		dataRepository.close();
		dataRepository = null;
	}
}
