package com.techhub.demo.junit;

import org.junit.Assert;
import org.junit.Test;

public class MathUtilTest {
	
	private MathUtil mathUtil=new MathUtil();

	@Test
	public void sumOfTest() {
		int sum=mathUtil.sumOf(7, 3);
		Assert.assertEquals(10, sum);
	}
	
	@Test
	public void mulOfTest() {
		int mul=mathUtil.mulOf(7, 3);
		Assert.assertEquals(21, mul);
	}
}
