package com.techhub.demo.junit.rules;

import org.junit.rules.TestRule;
import org.junit.runner.Description;
import org.junit.runners.model.Statement;

public class MyRule1 implements TestRule {

	@Override
	public Statement apply(Statement arg0, Description arg1) {
		System.out.println(arg0);
		System.out.println(arg1);
		return arg0;
	}

}
