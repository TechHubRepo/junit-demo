package com.techhub.demo.junit;

import org.junit.Assert;
import org.junit.Test;

public class DataRepositoryTest {

	private DataRepository dataRepository = new DataRepository();

	@Test
	public void getObjectTest() throws MyCustomException, Exception {
		String dataObject = dataRepository.getObject("ID0001", String.class);
		Assert.assertNotNull(dataObject);
	}
	
}
