https://youtu.be/bIlI4vJ94lQ
Code Coverage in JUnit.
