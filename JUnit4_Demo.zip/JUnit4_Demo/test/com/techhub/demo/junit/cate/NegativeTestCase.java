package com.techhub.demo.junit.cate;

public class NegativeTestCase {

}
