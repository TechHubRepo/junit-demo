package com.techhub.demo.junit.cate;

public @interface PostiveTestCase {

}
