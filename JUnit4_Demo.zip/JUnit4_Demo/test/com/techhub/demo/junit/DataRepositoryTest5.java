package com.techhub.demo.junit;

import java.util.concurrent.TimeUnit;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.rules.Timeout;

import com.techhub.demo.junit.rules.MyRule1;

public class DataRepositoryTest5 {

	private static DataRepository dataRepository;

	@Rule
	public ExpectedException thrown = ExpectedException.none();

	@Rule
	public Timeout timeout = new Timeout(100, TimeUnit.MILLISECONDS);

	@Rule
	public MyRule1 myRule1 = new MyRule1();

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		dataRepository = new DataRepository();
	}

	@Test
	public void getObjectTest() throws MyCustomException, Exception {
		thrown.expect(MyCustomException.class);
		thrown.expectMessage("id can't be null");
		dataRepository.getObject(null, String.class);
	}

	@Test(expected = MyCustomException.class)
	public void getObjectTestException() throws MyCustomException, Exception {
		dataRepository.getObjects(null);
	}
	
	@Test(expected = MyCustomException.class)
	public void getObjectTestException2() throws MyCustomException, Exception {
		dataRepository.getObjects("");
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		dataRepository.close();
		dataRepository = null;
	}
}
