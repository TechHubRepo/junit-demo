package com.techhub.demo.junit;

import org.junit.Assert;
import org.junit.Test;

public class ArrayUtilTest {

	@Test
	public void findElementTest() {
		int[] input =  { 5,2,3,7 };
		int index = ArrayUtil.findElement(input, 3);
		Assert.assertEquals(2, index);
	}
	
	@Test
	public void sortTest() {
		int[] input = { 5,2,3,7 };
		int[] output = { 2,3,5,7 };
		ArrayUtil.sort(input);
		Assert.assertArrayEquals(output, input);
	}
	
	@Test
	public void hasElementTest() {
		int[] input = { 5,2,3,7 };
		boolean flag=ArrayUtil.hasElement(input,9);
		Assert.assertFalse(flag);
	}
	
	
}
