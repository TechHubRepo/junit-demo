package com.techhub.demo.junit;

import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

public class DataRepositoryTest2 {

	private static DataRepository dataRepository;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.out.println("******* BeforeClass (setUp) *******");
		dataRepository = new DataRepository();
	}

	@Test
	public void getObjectTest() throws MyCustomException, Exception {
		String dataObject = dataRepository.getObject("ID0001", String.class);
		Assert.assertNotNull(dataObject);
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		System.out.println("******* AfterClass (tearDown) *******");
		dataRepository.close();
		dataRepository = null;
	}
}
