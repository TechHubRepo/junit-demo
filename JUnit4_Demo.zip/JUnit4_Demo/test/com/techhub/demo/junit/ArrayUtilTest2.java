package com.techhub.demo.junit;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import com.techhub.demo.junit.cate.NegativeTestCase;
import com.techhub.demo.junit.cate.PostiveTestCase;

public class ArrayUtilTest2 {

	private int[] inputArray;
	private static int[] orderedArray = { 2, 3, 5, 7 };

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.out.println("******* BeforeClass (setUp) *******");
		orderedArray = new int[4];
		orderedArray[0] = 2;
		orderedArray[1] = 3;
		orderedArray[2] = 5;
		orderedArray[3] = 7;
	}

	@Before
	public void setUp() throws Exception {
		System.out.println("******* Before (setUp) *******");
		this.inputArray = new int[4];
		this.inputArray[0] = 5;
		this.inputArray[1] = 2;
		this.inputArray[2] = 3;
		this.inputArray[3] = 7;
	}

	@Category(PostiveTestCase.class)
	@Test
	public void findElementTest() {
		int index = ArrayUtil.findElement(inputArray, 3);
		Assert.assertEquals(2, index);
	}

	@Category(NegativeTestCase.class)
	@Test
	public void findElementTest2() {
		int index = ArrayUtil.findElement(inputArray, 8);
		Assert.assertEquals(-1, index);
	}

	@Category(PostiveTestCase.class)
	@Test(timeout = 100)
	public void sortTest() {
		ArrayUtil.sort(inputArray);
		Assert.assertArrayEquals(orderedArray, inputArray);
	}

	@Category(NegativeTestCase.class)
	@Ignore
	@Test
	public void hasElementTest() {
		boolean flag = ArrayUtil.hasElement(inputArray, 9);
		Assert.assertFalse(flag);
	}
	
	@Category(PostiveTestCase.class)
	@Test
	public void hasElementTest2() {
		boolean flag = ArrayUtil.hasElement(inputArray, 7);
		Assert.assertTrue(flag);
	}

	@After
	public void tearDown() throws Exception {
		System.out.println("******* After (tearDown) *******");
		this.inputArray = null;
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		System.out.println("******* AfterClass (tearDown) *******");
		orderedArray = null;
	}
}