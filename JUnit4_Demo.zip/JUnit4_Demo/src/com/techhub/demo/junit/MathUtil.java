package com.techhub.demo.junit;

public class MathUtil {

	public int sumOf(int x, int y) {
		return x + y;
	}

	public int mulOf(int x, int y) {
		return x * y;
	}
}
